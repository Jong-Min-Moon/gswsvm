

1. Standard SVM: 레퍼런스 코드를 그대로 따라간다.
- 